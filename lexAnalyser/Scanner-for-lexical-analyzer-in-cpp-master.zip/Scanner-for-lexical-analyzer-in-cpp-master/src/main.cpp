#include "scanner.hpp"

int main()
{
  lexicalAnalyze("../program.txt");
  return 0;
}
